package ocean.fish;

/**
 * An interface that designates a fish as Eatable.
 *  
 * @author Andreas Wiese
 */
public interface Eatable {
	
}
